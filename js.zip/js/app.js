/**
 * app.js - Vanilla JS interactions for the TCS NQT Simulator UI
 */

document.addEventListener('DOMContentLoaded', () => {

    // Unlimited Practice Mode - Timer removed

    // Exam Page logic is already handled inline in exam.html for Monaco Editor and Timer.
    
    // --- Connect to Node.js AI Backend ---
    
    async function requestAITest(tierName, btnElement, counts) {
        const originalText = btnElement.innerHTML;
        btnElement.innerHTML = `<span class="mr-3 text-lg"><i class="ph ph-spinner animate-spin"></i> BUILDING ${tierName.toUpperCase()} TEST VIA AI... (Takes ~20s)</span>`;
        btnElement.classList.add('cursor-not-allowed', 'opacity-80');

        try {
            const response = await fetch('http://localhost:3000/api/generate-test', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId: 'guest',
                    aptitudeCount: counts.apt,
                    reasoningCount: counts.reas,
                    javaCount: counts.java
                })
            });

            if (!response.ok) {
                throw new Error('Backend API failed to generate test.');
            }

            const rawData = await response.json();
            const data = rawData.test;
            const sessionId = rawData.sessionId;
            
            // Re-map the raw Gemini JSON to match the exam.html expected structure
            const testPayload = {
                tier: tierName,
                timeLimitMinutes: 60, 
                aptitude: data.aptitude.map((q, i) => ({ ...q, uniqueId: 'apt_' + i })),
                reasoning: data.reasoning.map((q, i) => ({ ...q, uniqueId: 'reas_' + i })),
                java: data.java.map((q, i) => ({ ...q, uniqueId: 'java_' + i }))
            };
            
            localStorage.setItem('currentTestSession', sessionId);
            localStorage.setItem('currentTestData', JSON.stringify(testPayload));
            window.location.href = 'exam.html';

        } catch (err) {
            console.error(err);
            alert('Failed to connect to the Google Gemini REST API. Please check your internet connection.');
            btnElement.innerHTML = originalText;
            btnElement.classList.remove('cursor-not-allowed', 'opacity-80');
        }
    }

    const startFoundationBtn = document.getElementById('start-foundation-btn');
    if (startFoundationBtn) {
        startFoundationBtn.addEventListener('click', (e) => {
            e.preventDefault();
            requestAITest('Foundation', startFoundationBtn, { apt: 15, reas: 15, java: 5 });
        });
    }

    const startAdvancedBtn = document.getElementById('start-advanced-btn');
    if (startAdvancedBtn) {
        startAdvancedBtn.addEventListener('click', (e) => {
            e.preventDefault();
            requestAITest('Advanced', startAdvancedBtn, { apt: 10, reas: 10, java: 5 });
        });
    }

    // Manual Smoke Test Loader (Small array for quick testing)
    const smokeTestBtn = document.getElementById('smoke-test-btn');
    if (smokeTestBtn) {
        smokeTestBtn.addEventListener('click', (e) => {
            e.preventDefault();
            requestAITest('Smoke Test (Mini)', smokeTestBtn, { apt: 2, reas: 2, java: 1 });
        });
    }

    // Smooth transitions for hover states (handled mostly by CSS, but added here if complex JS logic is later needed)
    const glassCards = document.querySelectorAll('.glass-card');
    glassCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-4px)';
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0px)';
        });
    });

});
